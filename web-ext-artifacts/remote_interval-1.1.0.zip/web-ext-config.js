module.exports = {
  verbose: true,
  run: {
    startUrl: ["https://stackoverflow.com/jobs"],
    // browserConsole: true,
  },
};
