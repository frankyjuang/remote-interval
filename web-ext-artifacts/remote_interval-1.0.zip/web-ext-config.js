module.exports = {
  verbose: true,
  run: {
    startUrl: ["https://stackoverflow.com/jobs"],
    // browserConsole: true,
    target: ["firefox-desktop"],
    // target: ["firefox-desktop", "chromium"],
  },
};
